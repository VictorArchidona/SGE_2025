import random
from Node import Node  # Clase para representar un nodo en el grafo
from Edge import Edge  # Clase para representar una arista entre dos nodos

class Graph:
    """
    Clase Graph que representa un grafo dirigido. Permite la creación de nodos,
    la adición de aristas entre nodos, y la visualización de los nodos en el grafo.
    """

    def __init__(self):
        """
        Inicializa un grafo vacío.
        """
        self.nodes = []
