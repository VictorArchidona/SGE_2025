from Graph import Graph
import Utility

def main():
    """
    Función principal que carga archivos de texto en un grafo y genera una "canción"
    a partir de las conexiones entre palabras.
    
    Crea un grafo con palabras de múltiples archivos de texto, y luego genera
    una secuencia de palabras basada en las conexiones del grafo.
    """


if __name__ == "__main__":
    main()
