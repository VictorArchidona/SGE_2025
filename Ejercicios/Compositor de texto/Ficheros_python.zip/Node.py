class Node:
    """
    Clase Node que representa un nodo en el grafo, con un contenido asociado
    y una lista de aristas que conectan este nodo con otros.
    """

    def __init__(self, content):
        """
        Inicializa un nodo con un contenido y una lista vacía de aristas.
        
        Args:
            content (str): Contenido o valor asociado al nodo.
        """
        self.content = content  # Almacena el valor o contenido del nodo
        self.edges = []  # Lista para almacenar aristas asociadas a este nodo
