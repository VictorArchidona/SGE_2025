class Edge:
    def __init__(self, destino):
        self.destino = destino
        self.weight = 1
